India Socio Economic Data

Population data, housing data, and socio economic data for each district


Context

2011 India census data. Includes population/demographic data , housing data and socio economic data for each district.

Content

india-districts-census-2011.csv - Population enumeration data with expanded columns.
indiacensushousing-hlpca-full.csv - Housing statistics for total (rural + urban) population by district.
gdpAndhraPradesh1.csv , gdpAndhraPradesh2 : Contains GDP data for state AP.
gdp_ArunachalPradesh.csv: Contains GDP data for state ArunachalPradesh.
gdpAssam1.csv, gdpAssam2.csv : Contains GDP data for state Assam.
gdpBihar1.csv , gdpBihar2.csv : Contains GDP data for state Bihar.
gdp_Chattisgarh.csv : Contains GDP data for state Chattisgarh.
gdp_Haryana.csv : Contains GDP data for state Haryana.
gdp_HimachalPradesh.csv : Contains GDP data for state HimachalPradesh.
gdp_Jharkhand.csv : Contains GDP data for state Jharkhand.
gdpKarnataka1.csv , gdpKarnataka2.csv : Contains GDP data for state Karnataka.
gdpKerala1.csv , gdpKerala2.csv : Contains GDP data for state Kerala.
gdp_MadhyaPradesh.csv : Contains GDP data for state MadhyaPradesh.
gdpMaharashtra1.csv , gdpMaharashtra2.csv : Contains GDP data for state Maharashtra.
gdp_Manipur.csv : Contains GDP data for state Manipur.
gdp_Meghalaya.csv : Contains GDP data for state Meghalaya.
gdp_Mizoram.csv : Contains GDP data for state Mizoram.
gdpOdisha1.csv , gdpOdisha2.csv : Contains GDP data for state Odhisha.
gdpPunjab1.csv , gdpPunjab2.csv : Contains GDP data for state Punjab.
gdpRajasthan1.csv , gdpRajasthan2.csv : Contains GDP data for state Rajasthan.
gdp_Sikkim.csv : Contains GDP data for state Sikkim.
gdp_Tamilnadu.csv : Contains GDP data for state Tamilnadu.
gdp_Uttarakhand.csv : Contains GDP data for state Uttarakhand.
gdpUttarPradesh1.csv , gdpUttarPradesh2.csv : Contains GDP data for state UttarPradesh.
gdpWestBengal1.csv , gdpWestBengal2.csv : Contains GDP data for state West Bengal.
Acknowledgements

https://www.kaggle.com/danofer/india-census

https://www.kaggle.com/umeshnarayanappa/explore-census-2001-india

http://udise.in/drc.htm

https://data.gov.in/catalog/district-wise-gdp-and-growth-rate-current-price2004-05

https://data.gov.in/catalog/district-wise-gdp-and-growth-rate-constant-price1999-2000

Banner photo by @ishant_mishra54 from Unsplash.

Inspiration

What are the socioeconomic trends in different parts of India?
